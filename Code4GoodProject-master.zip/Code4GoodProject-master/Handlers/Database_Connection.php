<?php 

$dbServername = "localhost";
$dbUsername = "root";
$password = "";
$dbName = "code4good";

$con = mysqli_connect($dbServername , $dbUsername , $password , $dbName);