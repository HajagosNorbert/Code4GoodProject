<?php
<?include 'Header.php'?>
echo 
<?include 'Footer.php'?>

