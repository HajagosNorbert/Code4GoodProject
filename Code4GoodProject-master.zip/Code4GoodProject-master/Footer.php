<Footer>
    <div class="copy">
        @copyright Teen Agent 2018-2024
    </div>
</Footer>
</body>

</html>
